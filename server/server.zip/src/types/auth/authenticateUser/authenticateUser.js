function AuthenticateUser()
{
    this.email = '';
    this.isAuthenticated = false;
    this.role = '';
}

module.exports = AuthenticateUser;
