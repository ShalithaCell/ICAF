# ICAF - International Conference on Application Frameworks - Server Side
Web application for a Conference management tool


## Tech
---
